import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import {ReceiptText, IndianRupee, Users, LogOut, Plus, Search, Trash2, Printer, MessageCircle} from "lucide-react";
import {jsPDF} from "jspdf";
import "./style.css";

const API = "http://localhost:5000/api";
const mandal = "Gurudatta Mitra Mandal";
const mandalAddress = "Parner, Chede Mala";

function App(){
  const [token,setToken]=useState(localStorage.getItem("token"));
  const [login,setLogin]=useState({username:"admin",password:"admin123"});
  const [dash,setDash]=useState({});
  const [rows,setRows]=useState([]);
  const [search,setSearch]=useState("");
  const [show,setShow]=useState(false);
  const [form,setForm]=useState({donorName:"",mobile:"",address:"",amount:"",paymentMode:"Cash",note:""});
  const [selected,setSelected]=useState(null);

  async function api(path,opts={}){
    const r=await fetch(API+path,{...opts,headers:{"Content-Type":"application/json",Authorization:"Bearer "+token,...opts.headers}});
    const data=await r.json();
    if(!r.ok) throw Error(data.message||"Error");
    return data;
  }
  async function refresh(){
    setDash(await api("/dashboard"));
    setRows(await api("/receipts?search="+encodeURIComponent(search)));
  }
  useEffect(()=>{if(token) refresh().catch(()=>logout())},[token,search]);

  function logout(){localStorage.removeItem("token");setToken(null)}
  async function doLogin(e){
    e.preventDefault();
    try{const d=await fetch(API+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(login)}).then(r=>r.json()); if(!d.token) throw Error(d.message); localStorage.setItem("token",d.token);setToken(d.token)}catch(e){alert(e.message)}
  }
  async function save(e){
    e.preventDefault();
    try{const r=await api("/receipts",{method:"POST",body:JSON.stringify({...form,amount:Number(form.amount)})});setShow(false);setForm({donorName:"",mobile:"",address:"",amount:"",paymentMode:"Cash",note:""});setSelected(r);await refresh()}catch(e){alert(e.message)}
  }
  async function del(id){if(confirm("Delete this receipt?")){await api("/receipts/"+id,{method:"DELETE"});refresh()}}
  async function sendWhatsApp(r){
    const phone = String(r.mobile || "").replace(/\\D/g, "");
    if (!phone) {
      alert("या पावतीसाठी मोबाईल नंबर उपलब्ध नाही.");
      return;
    }
    const doc = new jsPDF({unit:"mm", format:"a5"});
    doc.setDrawColor(40);
    doc.rect(10,10,128,190);
    doc.setFontSize(18);
    doc.text("Gurudatta Mitra Mandal", 74, 23, {align:"center"});
    doc.setFontSize(11);
    doc.text("गणपती देणगी पावती", 74, 31, {align:"center"});
    doc.setFontSize(10);
    doc.text("Parner, Chede Mala", 74, 38, {align:"center"});
    doc.line(18,43,130,43);
    const lines = [
      ["पावती क्र.", String(r.receiptNo)],
      ["दिनांक", new Date(r.createdAt).toLocaleDateString("en-IN")],
      ["देणगीदार", r.donorName],
      ["मोबाईल", r.mobile || "-"],
      ["पत्ता", r.address || "-"],
      ["पेमेंट", r.paymentMode],
      ["रक्कम", "Rs. " + Number(r.amount).toLocaleString("en-IN")]
    ];
    let y=53;
    doc.setFontSize(10);
    for (const [k,v] of lines) {
      doc.text(k, 20, y);
      doc.text(String(v).slice(0,48), 55, y);
      y += 12;
    }
    if (r.note) { doc.text("Note: " + String(r.note).slice(0,55), 20, y+2); }
    doc.text("अधिकृत सही", 105, 184, {align:"center"});
    const blob = doc.output("blob");
    const file = new File([blob], `Ganpati-Receipt-${r.receiptNo}.pdf`, {type:"application/pdf"});
    const message = `🪔 Gurudatta Mitra Mandal, Parner\\nगणपती देणगी पावती क्र. ${r.receiptNo}\\nदेणगीदार: ${r.donorName}\\nरक्कम: ₹${Number(r.amount).toLocaleString("en-IN")}\\nधन्यवाद! 🙏`;
    try {
      if (navigator.canShare && navigator.canShare({files:[file]})) {
        await navigator.share({files:[file], text:message});
        return;
      }
    } catch(e) {
      if (e?.name === "AbortError") return;
    }
    window.open("https://wa.me/" + (phone.length===10 ? "91"+phone : phone) + "?text=" + encodeURIComponent(message), "_blank");
    alert("WhatsApp उघडले आहे. PDF पावती attach करण्यासाठी share पर्याय वापरा.");
  }

  function printReceipt(r){
    const w=window.open("","_blank","width=650,height=700");
    w.document.write(`<html><head><title>Receipt ${r.receiptNo}</title><style>body{font-family:Arial;padding:30px}.receipt{border:2px solid #222;padding:24px;max-width:520px;margin:auto}h1{text-align:center;margin:0 0 5px}h3{text-align:center;margin:5px 0 25px}.row{display:flex;justify-content:space-between;border-bottom:1px solid #ddd;padding:10px 0}.amount{font-size:24px;font-weight:bold;text-align:center;margin:25px 0}.sign{margin-top:45px;text-align:right}</style></head><body><div class="receipt"><div class="brand"><img src="/gurudatta-mandal-logo.jpeg" class="receipt-logo"/><div><h1>${mandal}</h1><div class="maharaj">छत्रपती शिवाजी महाराज • गणेशोत्सव २०२६</div></div></div><h3>गणपती देणगी पावती</h3><div class="address">${mandalAddress}</div><div class="row"><b>पावती क्र.</b><span>${r.receiptNo}</span></div><div class="row"><b>दिनांक</b><span>${new Date(r.createdAt).toLocaleDateString("en-IN")}</span></div><div class="row"><b>देणगीदार</b><span>${r.donorName}</span></div><div class="row"><b>मोबाईल</b><span>${r.mobile||"-"}</span></div><div class="row"><b>पत्ता</b><span>${r.address||"-"}</span></div><div class="row"><b>पेमेंट</b><span>${r.paymentMode}</span></div><div class="amount">₹ ${Number(r.amount).toLocaleString("en-IN")}</div><div>${r.note||""}</div><div class="sign">अधिकृत सही</div></div><script>window.print()</script></body></html>`);
    w.document.close();
  }

  if(!token) return <div className="login"><form className="login-card" onSubmit={doLogin}><div className="login-logo">🪔</div><h1>Gurudatta Mitra Mandal</h1><div className="login-place">Parner, Chede Mala</div><p className="login-title">Admin Login</p><input placeholder="Username" value={login.username} onChange={e=>setLogin({...login,username:e.target.value})}/><input type="password" placeholder="Password" value={login.password} onChange={e=>setLogin({...login,password:e.target.value})}/><button>Login</button><small className="secure-note">🔒 अधिकृत वापरकर्त्यांसाठी</small></form></div>;

  return <div className="app">
    <header><div><div className="sitebrand"><img src="/gurudatta-mandal-logo.jpeg" alt="Gurudatta Mitra Mandal" /><div><h2>{mandal}</h2><span>📍 {mandalAddress} • Donation & Receipt Management</span></div></div></div><button className="dark" onClick={logout}><LogOut size={17}/> Logout</button></header>
    <main>
      <div className="cards"><Card icon={<IndianRupee/>} title="Total Collection" value={"₹ "+(dash.totalAmount||0).toLocaleString("en-IN")}/><Card icon={<IndianRupee/>} title="Today's Collection" value={"₹ "+(dash.todayAmount||0).toLocaleString("en-IN")}/><Card icon={<ReceiptText/>} title="Total Receipts" value={dash.totalReceipts||0}/><Card icon={<Users/>} title="Today's Receipts" value={dash.todayReceipts||0}/></div>
      <section className="panel"><div className="toolbar"><div className="search"><Search size={18}/><input placeholder="Search donor, mobile or receipt no." value={search} onChange={e=>setSearch(e.target.value)}/></div><button onClick={()=>setShow(true)}><Plus size={18}/> New Receipt</button></div>
      <div className="tablewrap"><table><thead><tr><th>No.</th><th>Donor</th><th>Mobile</th><th>Amount</th><th>Mode</th><th>Date</th><th>Action</th></tr></thead><tbody>{rows.map(r=><tr key={r._id}><td>#{r.receiptNo}</td><td>{r.donorName}</td><td>{r.mobile}</td><td>₹ {r.amount.toLocaleString("en-IN")}</td><td>{r.paymentMode}</td><td>{new Date(r.createdAt).toLocaleDateString("en-IN")}</td><td><button className="icon" onClick={()=>printReceipt(r)} title="Print"><Printer size={16}/></button><button className="icon wa" onClick={()=>sendWhatsApp(r)} title="WhatsApp"><MessageCircle size={16}/></button><button className="icon danger" onClick={()=>del(r._id)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div></section>
    </main>
    {show&&<div className="modal"><form className="modalbox" onSubmit={save}><h2>New Donation Receipt</h2><input required placeholder="Donor name *" value={form.donorName} onChange={e=>setForm({...form,donorName:e.target.value})}/><input placeholder="Mobile number" value={form.mobile} onChange={e=>setForm({...form,mobile:e.target.value})}/><input placeholder="Address" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/><input required type="number" min="1" placeholder="Amount ₹ *" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})}/><select value={form.paymentMode} onChange={e=>setForm({...form,paymentMode:e.target.value})}>{["Cash","UPI","Bank Transfer","Cheque"].map(x=><option key={x}>{x}</option>)}</select><textarea placeholder="Note" value={form.note} onChange={e=>setForm({...form,note:e.target.value})}/><div className="actions"><button type="button" className="secondary" onClick={()=>setShow(false)}>Cancel</button><button>Save Receipt</button></div></form></div>}
  </div>
}
function Card({icon,title,value}){return <div className="card"><div className="ico">{icon}</div><div><small>{title}</small><strong>{value}</strong></div></div>}
createRoot(document.getElementById("root")).render(<App/>);
