# Ganpati Receipt Management System

Full-stack starter for a Ganpati Mandal donation/receipt website.

## Features
- Admin login with JWT
- Dashboard with total collection, today's collection and receipt count
- Create donation receipts with auto receipt number
- Search/filter receipts
- Printable A5-style receipt
- Delete receipts
- Donor details: name, mobile, address, amount, payment mode, note
- MongoDB database
- React + Vite frontend
- Express backend

## Setup

### Backend
cd backend
npm install
copy `.env.example` to `.env`
Set MONGO_URI and JWT_SECRET.
npm run dev

Default admin credentials:
- username: admin
- password: admin123

Change these before production.

### Frontend
cd frontend
npm install
npm run dev

Open the URL shown by Vite, usually http://localhost:5173.

## Production notes
Use HTTPS, change the default admin password, use a strong JWT secret, restrict MongoDB access, and configure CORS for your production domain.
