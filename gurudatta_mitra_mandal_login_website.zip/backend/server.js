import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const receiptSchema = new mongoose.Schema({
  receiptNo: { type: Number, unique: true },
  donorName: { type: String, required: true, trim: true },
  mobile: { type: String, default: "" },
  address: { type: String, default: "" },
  amount: { type: Number, required: true, min: 1 },
  paymentMode: { type: String, enum: ["Cash", "UPI", "Bank Transfer", "Cheque"], default: "Cash" },
  note: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now }
});
const Receipt = mongoose.model("Receipt", receiptSchema);

const userSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  passwordHash: String
});
const User = mongoose.model("User", userSchema);

function auth(req, res, next) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ message: "Login required" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired token" });
  }
}

app.get("/api/health", (_, res) => res.json({ ok: true }));

app.post("/api/auth/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user || !(await bcrypt.compare(password, user.passwordHash)))
    return res.status(401).json({ message: "Invalid username or password" });
  const token = jwt.sign({ id: user._id, username }, process.env.JWT_SECRET, { expiresIn: "12h" });
  res.json({ token, username });
});

app.post("/api/auth/setup", async (req, res) => {
  const exists = await User.countDocuments();
  if (exists) return res.status(403).json({ message: "Admin already exists" });
  const hash = await bcrypt.hash(req.body.password || "admin123", 12);
  await User.create({ username: req.body.username || "admin", passwordHash: hash });
  res.json({ message: "Admin created" });
});

app.get("/api/receipts", auth, async (req, res) => {
  const { search = "", from, to, paymentMode } = req.query;
  const q = {};
  if (search) q.$or = [
    { donorName: { $regex: search, $options: "i" } },
    { mobile: { $regex: search, $options: "i" } },
    { receiptNo: Number.isNaN(Number(search)) ? -1 : Number(search) }
  ];
  if (paymentMode) q.paymentMode = paymentMode;
  if (from || to) {
    q.createdAt = {};
    if (from) q.createdAt.$gte = new Date(from + "T00:00:00");
    if (to) q.createdAt.$lte = new Date(to + "T23:59:59");
  }
  const rows = await Receipt.find(q).sort({ receiptNo: -1 }).limit(500);
  res.json(rows);
});

app.post("/api/receipts", auth, async (req, res) => {
  const last = await Receipt.findOne().sort({ receiptNo: -1 });
  const receiptNo = (last?.receiptNo || 0) + 1;
  const receipt = await Receipt.create({ ...req.body, receiptNo });
  res.status(201).json(receipt);
});

app.delete("/api/receipts/:id", auth, async (req, res) => {
  await Receipt.findByIdAndDelete(req.params.id);
  res.json({ message: "Receipt deleted" });
});

app.get("/api/dashboard", auth, async (_, res) => {
  const all = await Receipt.find();
  const todayKey = new Date().toDateString();
  const today = all.filter(r => new Date(r.createdAt).toDateString() === todayKey);
  res.json({
    totalAmount: all.reduce((s, r) => s + r.amount, 0),
    todayAmount: today.reduce((s, r) => s + r.amount, 0),
    totalReceipts: all.length,
    todayReceipts: today.length
  });
});

const port = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/ganpati_receipts")
  .then(async () => {
    if (!(await User.countDocuments())) {
      const hash = await bcrypt.hash("admin123", 12);
      await User.create({ username: "admin", passwordHash: hash });
    }
    app.listen(port, () => console.log(`API running on http://localhost:${port}`));
  })
  .catch(err => {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  });
